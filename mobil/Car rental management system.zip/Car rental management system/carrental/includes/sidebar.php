<div class="profile_nav">
  <ul>
    <li><a href="profile.php">Profile Settings</a></li>
    <li><a href="update_password.php">Update Password</a></li>
    <li><a href="my_booking.php">My Booking</a></li>
    <li><a href="logout.php">Sign Out</a></li>
  </ul>
</div>
</div>
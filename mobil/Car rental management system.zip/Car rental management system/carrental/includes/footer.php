<footer id="footer">
  <div class="container">
    <div class="copyright">
      &copy; Copyright <strong>Carrental portal</strong>. All Rights Reserved
    </div>
  </div>
</footer>
<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

function cek($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

        $quer = "SELECT * FROM  tabel_perusahaan";
        $res = mysqli_query($conn, $quer);
        $data_perusahaan = mysqli_fetch_assoc($res);

        $sql = "SELECT * FROM tabel_perusahaan";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $data = mysqli_fetch_assoc($result);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['update'])) {

            $nama = cek($_POST['nama']);

            $new_image = $_FILES['gambar']['name'];
            $old_image = $_POST['gambar_lama'];

            if($new_image != '')
            {
              $update_filename = $_FILES['gambar']['name'];
            }
            else
            {
              $update_filename = $old_image;
            }
            if( $_FILES['gambar']['name'] !='')
            {
              if(file_exists("gambar/" . $_FILES['gambar']['name']))
              {
                echo "<script>alert('data sudah ada');</script>";
              }
            }
              $sql = "UPDATE tabel_perusahaan SET nama='$nama', gambar='$update_filename'";
              $result = mysqli_query($conn, $sql);

              if($result)
              {
                if($_FILES['gambar']['name'] !='')
                {
                  move_uploaded_file($_FILES["gambar"]["tmp_name"], "gambar/".$_FILES["gambar"]["name"]);
                  unlink("gambar/".$old_image);
                }
                echo "<script>alert('Data berhasil diubah');</script>";
              }
              else
              {
                echo "<script>alert('Data gagal diubah');</script>";
              
            }
          
        }
    }
            
}
                    

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data Perusahaan</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $sourcePath ?>/public/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $sourcePath ?>/public/dist/css/adminlte.min.css">
  <link rel="icon" href="<?php echo "gambar/".$data['gambar'];   ?>" type="image/icon-type">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php include "$sourcePath/components/navbar.php"; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php $currentPageActive = 'perusahaan'; include "$sourcePath/components/sidebar.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Perusahaan</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Masukkan Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form>
                <div class="card-body">
                  <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan nama merk" value="<?php echo $data['nama']; ?>" readonly>
                  </div>

                  <div class="form-group">
                    <label for="gambar">Gambar</label>
                        
                   
                    <div class="gambar-bg col" style=" margin-top: 15px;">
                            <img style="width: 80px; " src="<?php echo "gambar/".$data['gambar'];   ?>" alt="">
                        </div>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="button" class="btn btn-primary center-block" data-toggle="modal" data-target="#updateData">Update</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  
  <!-- /.content-wrapper -->
 
  <?php include "$sourcePath/components/footer.php"; ?>

  <div class="modal fade" id="updateData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah Merek</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    <label for="nama">Nama:</label>
                                    <input type="text" name="nama" id="nama" class="form-control" value="<?php echo $data['nama']; ?>">

                                    <label for="gambar">Gambar</label>
                                    <input type="file" name="gambar" class="form-control" >
                                    <input type="hidden" name="gambar_lama" class="form-control bg-light" value="<?php echo $data['gambar']; ?>">
                                        
                                    <img style="width: 50px; " src="<?php echo "gambar/".$data['gambar'];   ?>" alt="">

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                        <button type="submit" id='update' name='update' class="btn btn-primary">Ubah</button>
                                    </div>

                                </form>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo $sourcePath ?>/public/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>

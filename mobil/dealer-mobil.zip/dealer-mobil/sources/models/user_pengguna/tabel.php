<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['tambahButton'])) {
            $username = $_POST['username'];
            $nama_lengkap = $_POST['nama_lengkap'];
            $nomor_hp = $_POST['nomor_hp'];
            $email = $_POST['email'];
            $alamat = $_POST['alamat'];
            $password = md5($_POST['password']);
            $cpassword = md5($_POST['cpassword']);
         
            if ($password == $cpassword) {
                $sql = "SELECT * FROM tabel_akun WHERE email='$email'";
                $result = mysqli_query($conn, $sql);
                if (!$result->num_rows > 0) {
                    $sql = "INSERT INTO tabel_akun (username, nama_lengkap, nomor_hp, email, alamat, password)
                            VALUES ('$username', '$nama_lengkap', '$nomor_hp', '$email', '$alamat', '$password')";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        echo "<script>alert('Selamat, registrasi berhasil!')</script>";
                        $username = "";
                        $email = "";
                        $_POST['password'] = "";
                        $_POST['cpassword'] = "";
                    } else {
                        echo "<script>alert('Woops! Terjadi kesalahan.')</script>";
                    }
                } else {
                    echo "<script>alert('Woops! Email Sudah Terdaftar.')</script>";
                }
                 
            } else {
                echo "<script>alert('Password minimal 8 karakter')</script>";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data Akun Pembeli</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'user_pengguna'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Akun Pembeli</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#tambahData" style="margin-bottom: 30px;">Tambah User</button>

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Pembeli</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                <thead>
                                    <tr style="white-space: nowrap !important; text-align: center;">
                                        <th>No</th>
                                        <th>Username</th>
                                        <th>Nama Lengkap</th>
                                        <th>Nomor HP</th>
                                        <th>Email</th>
                                        <th>Alamat</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <!-- Table body -->
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM tabel_akun ORDER BY nama_lengkap ASC";
                                    $result = mysqli_query($conn, $sql);
                                    $no = 0;
                                    foreach ($result as $row) {
                                        $no++;
                                    ?>
                                        <tr>
                                            <td><?php echo $no; ?></td>
                                            <td><?php echo $row['username']; ?></td>
                                            <td><?php echo $row['nama_lengkap']; ?></td>
                                            <td><?php echo $row['nomor_hp']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['alamat']; ?></td>
                                            
                                            <td style="display: flex; flex-direction: row; justify-content: center;">
                                                <a type="submit" class="btn btn-danger center-block" href="hapus.php?id=<?php echo $row['id']; ?>">Hapus</a>
                                                <a style="margin-left: 0.5rem !important; white-space: nowrap !important;" type="submit" class="btn btn-danger center-block" href="ubahPassword.php?id=<?php echo $row['id']; ?>">Ubah Password</a>
                                                <a style="margin-left: 0.5rem !important;" type="submit" class="btn btn-info center-block" href="ubah.php?id=<?php echo $row['id']; ?>">Ubah</a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
  </div>


 
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah User</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                    <label for="username">Username:</label>
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Username" required>

                                    <label for="nama_lengkap">Nama Lengkap:</label>
                                    <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" placeholder="Nama Lengkap" required>

                                    <label for="nomor_hp">Nomor HP:</label>
                                    <input type="text" name="nomor_hp" id="nomor_hp" class="form-control" placeholder="Nomor HP" required>

                                    <label for="email">Email:</label>
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Email" required>

                                    <label for="alamat">alamat:</label>
                                    <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Alamat" required>

                                    <label for="password">Password:</label>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>

                                    <label for="cpassword">Konfirmasi Password:</label>
                                    <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="Konfirmasi Password" required>
                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

           
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->

</body>
</html>

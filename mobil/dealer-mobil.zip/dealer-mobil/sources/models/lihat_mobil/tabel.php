<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $id_jenis = $_GET['id_jenis'];
    $sql = "SELECT * FROM tabel_merk WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    $data_merk = mysqli_fetch_assoc($result);

    $sql = "SELECT * FROM tabel_jenis WHERE id='$id_jenis'";
    $result = mysqli_query($conn, $sql);
    $data_jenis = mysqli_fetch_assoc($result);
   
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data Mobil | <?php echo $data_merk['nama']; ?></title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'merk'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
            <div class="banner-logo" style="background-color: rgba(255,255,255,.75); padding:16px; border-radius: 15px; box-shadow:  5px 5px 10px #888888; margin-left: 10px;">
                            <img style="width: 80px;" src="../merk/gambar/<?php echo $data_merk['gambar'];?>" alt="">
                        </div>
                            <p style="font-weight: 900; text-align: center; margin-left: 30px; margin-top: 20px; font-size: 40px;"><?php echo $data_merk['nama']; ?></p>
         
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            
            
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo $data_jenis['nama']; ?></h3>
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                  <thead>
                  <tr>
                      <th>No</th>
                      <th>Nama</th>
                      <th>Tahun</th>
                      <th>Gambar</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $sql = "SELECT * FROM tabel_mobil WHERE id_merk = $id AND id_jenis = $id_jenis  ORDER BY nama";
                  $result = mysqli_query($conn, $sql);
                  $no = 0;
                  foreach ($result as $row) {
                      $no++;

                  ?>
                      <tr>
                          <td><?php echo $no; ?></td>
                          <td><?php echo $row['nama']; ?></td>
                          <td><?php echo $row['tahun']; ?></td>
                          <td><a href="<?php echo $sourcePath ?>/models/lihat_gambar/mobil2.php?id=<?php echo $row['id'] ?>"><img style="width: 50px;" src="../gambar_mobil/<?php echo $row['gambar'];?>" alt=""></a></td>
                      </tr>
                  <?php
                  }
                  ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <a href="../lihat_jenis/tabel.php?id=<?php echo $id; ?>&id_jenis=<?php echo $row['id'] ?>" class="btn btn-danger " type="button" style="margin-left: 8px;">Kembali</a>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  
  
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>
  
  

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["excel", "pdf"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>

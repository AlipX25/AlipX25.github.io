<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 3, "$sourcePath/../");

if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['tambahButton'])) {
            $username = $_POST['username'];
            $nama_lengkap = $_POST['nama_lengkap'];
            $nomor_hp = $_POST['nomor_hp'];
            $email = $_POST['email'];
            $role = $_POST['role'];
            $gambar = $_FILES['gambar']['name'];
            $password = md5($_POST['password']);
            $cpassword = md5($_POST['cpassword']);
            $aktif = "1";

            $allowed_exttension = array('gif', 'png', 'jpg', 'jpeg');
            $filename = $_FILES['gambar']['name'];
            $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
            if (!in_array($file_extension, $allowed_exttension))
            {
                echo "<script>alert('hanya boleh jpg png jpeg dan gif);</script>";
                echo "<script>window.location='tabel.php';</script>";
            }
            else
            {
                if(file_exists("gambar/" . $_FILES['gambar']['name']))
                {
                    $filename = $_FILES['gambar']['name'];
                    echo "<script>alert('gambar sudah ada);</script>";
                    echo "<script>window.location='tabel.php';</script>";
                }
                 else 
                {

            if (is_numeric($nomor_hp)) {
                if ($password == $cpassword) {
                    $sql = "SELECT * FROM tabel_user WHERE username='$username'";
                    $result = mysqli_query($conn, $sql);

                    if ($result->num_rows == 0) {
                        $sql = "INSERT INTO tabel_user (username, nama_lengkap, password, nomor_hp, email, role, gambar, aktif) VALUES ('$username', '$nama_lengkap', '$password', '$nomor_hp', '$email', '$role', '$gambar', '$aktif')";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            move_uploaded_file($_FILES["gambar"]["tmp_name"], "gambar/".$_FILES["gambar"]["name"]);
                            echo "<script>alert('Data berhasil dibuat');</script>";
                            echo "<script>window.location='tabel.php';</script>";
                        } else if (!$result) {
                            echo '<script>alert("Data gagal dibuat");</script>';
                        }
                    } else if ($result->num_rows != 0) {
                        echo "<script>alert('Woops! Username sudah terdaftar')</script>";
                    }
                } else if ($password != $cpassword) {
                    echo "<script>alert('Konfirmasi password salah')</script>";
                }
            } else if (!is_numeric($nomor_hp)) {
                echo '<script>alert("Pastikan nomor HP hanya menggunakan angka");</script>';
            }
          }
        }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data User</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'user'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data User</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#tambahData" style="margin-bottom: 30px;">Tambah User</button>

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data User</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                <thead>
                                    <tr style="white-space: nowrap !important; text-align: center;">
                                        <th>No</th>
                                        <th>Username</th>
                                        <th>Nama Lengkap</th>
                                        <th>Nomor HP</th>
                                        <th>Email</th>
                                        <th>role</th>
                                        <th>Gambar</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <!-- Table body -->
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM tabel_user ORDER BY nama_lengkap ASC";
                                    $result = mysqli_query($conn, $sql);
                                    $no = 0;
                                    foreach ($result as $row) {
                                        $no++;
                                    ?>
                                        <tr>
                                            <td><?php echo $no; ?></td>
                                            <td><?php echo $row['username']; ?></td>
                                            <td><?php echo $row['nama_lengkap']; ?></td>
                                            <td><?php echo $row['nomor_hp']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['role']; ?></td>
                                            <td><a type="submit" href="<?php echo $sourcePath ?>/models/lihat_gambar/user.php?id=<?php echo $row['id'] ?>"><img style="width: 50px;" src="gambar/<?php echo $row['gambar'];?>" alt=""></a></td> 
                                            <td><?php echo $row['aktif'] == 1 ? 'aktif' : 'tidak aktif' ?></td>
                                            <td style="display: flex; flex-direction: row; justify-content: center;">
                                              <form action="hapus.php" method="POST">
                                                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                                  <input type="hidden" name="delete_gambar" value="<?php echo $row['gambar']; ?>">
                                                  <button type="submit" class="btn btn-danger center-block" name="delete_data">Hapus</button>
                                              </form>

                                                <?php if ($row["aktif"] == 1) { ?>
                                                    <a style="margin-left: 0.5rem !important;" type="submit" class="btn btn-danger center-block" href="aktif.php?id=<?php echo $row['id']; ?>">Matikan</a>
                                                <?php } else if ($row["aktif"] == 0) { ?>
                                                    <a style="margin-left: 0.5rem !important;" type="submit" class="btn btn-success center-block" href="aktif.php?id=<?php echo $row['id']; ?>">Aktifkan</a>
                                                <?php } ?>
                                                </td>
                                                <td style="display: flex; flex-direction: row; justify-content: center;">
                                                <a style="margin-left: 0.5rem !important; white-space: nowrap !important;" type="submit" class="btn btn-warning center-block" href="ubahPassword.php?id=<?php echo $row['id']; ?>">Ubah Password</a>
                                                <a style="align-self: flex-end; margin-left: 0.5rem !important;" type="submit" class="btn btn-info center-block" href="ubah.php?id=<?php echo $row['id']; ?>">Ubah</a>
                                                </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
  </div>


 
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah User</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">
                                    <label for="username">Username:</label>
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Username" required>

                                    <label for="nama_lengkap">Nama Lengkap:</label>
                                    <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" placeholder="Nama Lengkap" required>

                                    <label for="nomor_hp">Nomor HP:</label>
                                    <input type="text" name="nomor_hp" id="nomor_hp" class="form-control" placeholder="Nomor HP" required>

                                    <label for="email">Email:</label>
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Email" required>

                                    <label for="role">Role:</label>
                                    <select id="role" class="custom-select bg-light" name="role" required>
                                        <option selected disabled>Pilih Role</option>
                                        <option value='admin'>Admin</option>
                                        <option value='operator'>Operator</option>
                                    </select>

                                    <label for="gambar">Gambar:</label>
                                    <input type="file" name="gambar" id="gambar" class="form-control" required>

                                    <label for="password">Password:</label>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>

                                    <label for="cpassword">Konfirmasi Password:</label>
                                    <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="Konfirmasi Password" required>
                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

           
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->

</body>
</html>

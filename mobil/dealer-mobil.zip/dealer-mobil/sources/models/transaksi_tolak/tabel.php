<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");





?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data Transaksi</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'transaksi_tolak'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Transaksi di tolak</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
          


            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data transaksi yang di tolak</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                  <thead>
                  <tr>
                      <th>No</th>
                      <th>Nama</th>
                      <th>Alamat</th>
                      <th>Nomor HP</th> 
                      <th>Mobil</th> 
                      <th>Banyak Unit</th>
                      <th>Ditolak</th>
                     
                  </tr>
                  </thead>
                  <tbody>
                      <?php
                      $sql = "SELECT * FROM tabel_pembelian WHERE status='3' ORDER BY dibuat DESC";
                      $result = mysqli_query($conn, $sql);
                      $no = 0;
                      foreach ($result as $row) {
                          $no++;
                          $id_mobil = $row['id_mobil'];
                          $harga = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga FROM tabel_mobil WHERE id='$id_mobil'"))["harga"];
                          $nama_mobil =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_mobil WHERE id='$id_mobil'"))["nama"];
                          $harga = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga FROM tabel_mobil WHERE id='$id_mobil'"))["harga"];
                          $bayar = $row['bayar'];

                          $jumlah_mobil_dibeli = $row['banyak_unit'];
                          $hasil= $bayar - $jumlah_mobil_dibeli * $harga;

                          $id_akun = $row['id_akun'];
                          $nama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama_lengkap FROM tabel_akun WHERE id='$id_akun'"))["nama_lengkap"];
                          $alamat_pembeli = mysqli_fetch_assoc(mysqli_query($conn, "SELECT alamat FROM tabel_akun WHERE id='$id_akun'"))["alamat"];
                          $no_hp = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nomor_hp FROM tabel_akun WHERE id='$id_akun'"))["nomor_hp"];


                      ?>
                          <tr>
                              <td><?php echo $no; ?></td>
                              <td><?php echo $nama; ?></td>
                              <td><?php echo $alamat_pembeli; ?></td>
                              <td><?php echo $no_hp; ?></td>
                              <td><?php echo $nama_mobil; ?></td>
                              <td><?php echo $row['banyak_unit']; ?></td>
                              <td><?php echo $row['dibuat']; ?></td>
                          </tr>
                      <?php
                      }
                      ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>


<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["excel", "pdf"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });

  function total() {
   var harga =  parseInt(document.getElementById('harga_barang').value);
   var jumlah_beli =  parseInt(document.getElementById('quantity').value);
   var jumlah_harga = harga * jumlah_beli;
    document.getElementById('subtotal').value = jumlah_harga;
  }


</script>

</body>
</html>

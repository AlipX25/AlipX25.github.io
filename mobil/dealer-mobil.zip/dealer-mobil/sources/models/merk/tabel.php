<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_POST['tambahButton']))
        {
            $nama = $_POST['nama'];
            $negara = $_POST['negara'];
            $gambar = $_FILES['gambar']['name'];

            $allowed_exttension = array('gif', 'png', 'jpg', 'jpeg');
            $filename = $_FILES['gambar']['name'];
            $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
            if (!in_array($file_extension, $allowed_exttension))
            {
                echo "<script>alert('hanya boleh jpg png jpeg dan gif);</script>";
                echo "<script>window.location='tabel.php';</script>";
            }
            else
            {
                if(file_exists("gambar/" . $_FILES['gambar']['name']))
                {
                    $filename = $_FILES['gambar']['name'];
                    echo "<script>alert('gambar sudah ada);</script>";
                    echo "<script>window.location='tabel.php';</script>";
                }
                else 
                {

                    $sql = "INSERT INTO tabel_merk (nama, negara, gambar) VALUES ('$nama', '$negara', '$gambar')";
                    $result = mysqli_query($conn, $sql);

                    if($result)
                    {
                        move_uploaded_file($_FILES["gambar"]["tmp_name"], "gambar/".$_FILES["gambar"]["name"]);
                        echo "<script>alert('Data berhasil dimasukkan');</script>";
                        echo "<script>window.location='tabel.php';</script>";
                    }
                    else
                    {
                        echo "<script>alert('Data gagal dimasukkan');</script>";
                        echo "<script>window.location='tabel.php';</script>";
                    }
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Merek Mobil</title>
  <?php

  include "$sourcePath/components/header-tabel.php";
  

  ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

  $currentPageActive = 'merk'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="min-height: 40px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Merek</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#tambahData" style="margin-bottom: 30px;">Tambah Merek</button>
              
            
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Merek Mobil </h3>
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                  <thead>
                  <tr>
                      <th class="export">No</th>
                      <th class="export">Nama</th>
                      <th class="export">Asal Negara</th>
                      <th>Gambar</th>
                      <th class="export">Di Buat</th>
                      <th class="export">Di Ubah</th>
                      <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $sql = "SELECT * FROM tabel_merk ORDER BY nama";
                  $result = mysqli_query($conn, $sql);
                  $no = 0;
                  foreach ($result as $row) {
                      $no++;

                  ?>
                      <tr>
                          <td><?php echo $no; ?></td>
                          <td><?php echo $row['nama']; ?></td>
                          <td><?php echo $row['negara']; ?></td>
                          <td><a type="submit" href="<?php echo $sourcePath ?>/models/lihat_gambar/merk.php?id=<?php echo $row['id'] ?>"><img style="width: 50px;" src="gambar/<?php echo $row['gambar'];?>" alt=""></a></td>
                          <td><?php echo $row['dibuat']; ?></td>
                          <td><?php echo $row['diupdate']; ?></td>
                          <td class="d-flex" style="justify-content: center;">
                              <form action="hapus.php" method="POST">
                                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                  <input type="hidden" name="delete_gambar" value="<?php echo $row['gambar']; ?>">
                                  <button type="submit" class="btn btn-danger center-block" name="delete_data">Hapus</button>
                              </form>
                              <a style="margin-left: 0.5rem !important" type="submit" class="btn btn-info center-block" href="ubah.php?id=<?php echo $row['id']; ?>">Ubah</a>
                              <a style="margin-left: 0.5rem !important" type="submit" class="btn btn-info center-block" href="../lihat_jenis/tabel.php?id=<?php echo $row['id']; ?>">Lihat Mobil</a>
                          </td>
                      </tr>

                  <?php
                  }
                  ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  
  
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>
  
  <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah Merek</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    <label for="nama">Nama:</label>
                                    <input type="text" name="nama" id="nama" class="form-control" placeholder="Masukkan Merk" required>

                                    <label for="negara">Negara:</label>
                                    <input type="text" name="negara" id="negara" class="form-control" placeholder="Masukkan Negara" required>

                                    <label for="gambar">Gambar:</label>
                                    <input type="file" name="gambar" id="gambar" class="form-control" required>



                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": [{extend: "excel", exportOptions: {columns: ['.export']}}, {extend: "pdf", exportOptions: {columns: ['.export']}}, "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>

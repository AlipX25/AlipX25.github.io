<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

function cek($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$quer = "SELECT * FROM  tabel_perusahaan";
$res = mysqli_query($conn, $quer);
$data_perusahaan = mysqli_fetch_assoc($res);

if (isset($_SESSION["id"])) {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        $sql = "SELECT * FROM tabel_merk WHERE id='$id'";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $data = mysqli_fetch_assoc($result);
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['update'])) {
            $id = $_GET['id'];

            $nama = cek($_POST['nama']);
            $negara = cek($_POST['negara']);

            $new_image = $_FILES['gambar']['name'];
            $old_image = $_POST['gambar_lama'];

            if($new_image != '')
            {
              $update_filename = $_FILES['gambar']['name'];
            }
            else
            {
              $update_filename = $old_image;
            }

            if($_FILES['gambar']['name'] !='')
            {
              if(file_exists("gambar/" . $_FILES['gambar']['name']))
              {
                echo "<script>alert('data sudah ada');</script>";
                echo "<script>window.location='ubah.php?id=$id';</script>";
              }
              
              else{
                $sql = "UPDATE tabel_merk SET nama='$nama', negara='$negara', gambar='$update_filename' WHERE id='$id'";
                $result = mysqli_query($conn, $sql);

                if($result)
                {
                  if($_FILES['gambar']['name'] !='')
                  {
                    move_uploaded_file($_FILES["gambar"]["tmp_name"], "gambar/".$_FILES["gambar"]["name"]);
                    unlink("gambar/".$old_image);
                  }

                  echo "<script>alert('Data berhasil diubah');</script>";
                  echo "<script>window.location='ubah.php?id=$id';</script>";
                }
                else
                {
                  echo "<script>alert('Data gagal diubah');</script>";
                  echo "<script>window.location='ubah.php?id=$id';</script>";
                }

              }
            } else if (($_FILES['gambar']['name'] == '')) {
              $sql = "UPDATE tabel_merk SET nama='$nama', negara='$negara' WHERE id='$id'";
              $result = mysqli_query($conn, $sql);

              if($result)
              {
                echo "<script>alert('Data berhasil diubah');</script>";
                echo "<script>window.location='ubah.php?id=$id';</script>";
              }
              else
              {
                echo "<script>alert('Data gagal diubah');</script>";
                echo "<script>window.location='ubah.php?id=$id';</script>";
              }
            }
            
              
              
           
          
        }
    }
            
}            

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ubah Merek</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $sourcePath ?>/public/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $sourcePath ?>/public/dist/css/adminlte.min.css">
  <link rel="icon" href="<?php echo $sourcePath ?>/models/perusahaan/gambar/<?php echo $data_perusahaan['gambar'];   ?>" type="image/icon-type">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php include "$sourcePath/components/navbar.php"; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include "$sourcePath/components/sidebar.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ubah Merek</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Masukkan Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $_GET["id"]; ?>" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan nama merk" value="<?php echo $data['nama']; ?>">
                  </div>
                  <div class="form-group">
                    <label for="negara">Negara</label>
                    <input type="text" class="form-control" id="negera" name="negara" placeholder="Masukkan Negara" value="<?php echo $data['negara']; ?>">
                  </div>
                  <div class="form-group">
                    <label for="gambar">Gambar</label>
                        
                        <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="gambar" class="custom-file-input" >
                            <input type="hidden" name="gambar_lama" class="form-control bg-light" value="<?php echo $data['gambar']; ?>">
                            <label class="custom-file-label">Pilih file</label>
                        </div>
                      
                    </div>
                    <div class="gambar-bg col" style=" margin-top: 15px;">
                            <img style="width: 50px; " src="<?php echo "gambar/".$data['gambar'];   ?>" alt="">
                        </div>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" id='update' name='update' class="btn btn-primary">Ubah</button>
                  <a type="button" class="btn btn-danger center-block" href="tabel.php">Kembali</a>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
  <?php include "$sourcePath/components/footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo $sourcePath ?>/public/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>

<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

$sql = "SELECT SUM(bayar) AS total FROM `tabel_pembelian`";
$result = mysqli_query($conn, $sql);
$data_pembelian = mysqli_fetch_array($result);


if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['tambahButton'])) {
            $id_akun = $_POST['id_akun'];
            $id_mobil = $_POST['id_mobil'];
            $banyak_unit = $_POST['banyak_unit'];
            $bayar = $_POST['bayar'];
            $status = '1';
            $jumlah_mobil_hitung = mysqli_fetch_assoc(mysqli_query($conn, "SELECT jumlah_mobil FROM tabel_mobil WHERE id='$id_mobil'"))["jumlah_mobil"];
            $harga_mobil_hitung = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga FROM tabel_mobil WHERE id='$id_mobil'"))["harga"];
            
             if($jumlah_mobil_hitung >= $banyak_unit && $harga_mobil_hitung <= $bayar){

            

            $sql = "INSERT INTO tabel_pembelian (id_akun, id_mobil, banyak_unit, bayar, status) VALUES ('$id_akun', '$id_mobil', '$banyak_unit', '$bayar', '$status')";
            $result = mysqli_query($conn, $sql);

            if ($result) {

              // $sql = "SELECT * FROM tabel_pembelian ORDER BY nama_pembeli";
              // $result = mysqli_query($conn, $sql);
              // $data_mobil = mysqli_fetch_assoc($result);
              // $id_mobil = $data_mobil['id_mobil'];

              
              // $jumlah_mobil_dibeli = $data_mobil['banyak_unit'];

              $stok_mobil = $jumlah_mobil_hitung - $banyak_unit;

              $sql = "UPDATE tabel_mobil SET  jumlah_mobil='$stok_mobil' WHERE id='$id_mobil'";
              $result = mysqli_query($conn, $sql);

                echo "<script>alert('Data berhasil dibuat');</script>";
                echo "<script>window.location='tabel.php';</script>";
            } else if (!$result) {
                echo '<script>alert("Data gagal dibuat");</script>';
            }
          }
          else {
            echo '<script>alert("Mobil Habis atau Pembayaran Kurang");</script>';
          }
        }
        
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Rekap per Merek</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'rekap_merk'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Transaksi per Merek</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            


            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Riwayat</h3>
                
              </div>
              <!-- /.card-header -->
            
              <div class="card-body">
              
              
              
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                
                  <thead>
                  <tr>
                      <th class="export">No</th>
                      <th class="export">Merek</th>
                      <th class="export">Mobil Terjual</th>
                      <th class="export">Total</th>
                      <th>Aksi</th>
                  </tr>
                  </thead>
                  
                  <tbody>
                      <?php
                     
                        $sql_merk = "SELECT * FROM tabel_merk ORDER BY nama DESC";
                        $result_merk = mysqli_query($conn, $sql_merk);
                      
                      $no = 0;

                      $total_keseluruhan = 0;

                      foreach ($result_merk as $row_merk) {
                          $no++;
                          $mobil_terjual = 0;
                          $total = 0;
                         
                          $id_merk = $row_merk['id'];

                          $sql_mobil = "SELECT * FROM tabel_mobil WHERE id_merk='$id_merk'";
                          $result_mobil = mysqli_query($conn, $sql_mobil);

                          foreach ($result_mobil as $row_mobil) {
                            $id_mobil = $row_mobil['id'];

                            $sql_pembelian = "SELECT * FROM tabel_pembelian WHERE status='1' AND id_mobil='$id_mobil'";
                            $result_pembelian = mysqli_query($conn, $sql_pembelian);

                            foreach ($result_pembelian as $row_pembelian) {

                                $mobil_terjual += $row_pembelian['banyak_unit'];
                                $total += $row_pembelian['banyak_unit'] * $row_mobil['harga'];
        
                              }

                          }

                          $total_keseluruhan += $total;

                      ?>
                          <tr>
                              <td><?php echo $no; ?></td>
                              <td><?php echo $row_merk['nama']; ?></td>
                              <td><?php echo $mobil_terjual; ?></td>
                              <td>Rp<?php echo number_format($total,0,',','.'); ?></td>
                              <td>
                              <a style="margin-left: 0.5rem !important" type="submit" class="btn btn-info center-block" href="data_mobil.php?id=<?php echo $id_merk; ?>">Lihat Data</a>
                              </td>
                          </tr>
                      <?php
                      }
                      ?>
                  </tbody>
                  <tfoot>
                  <tr>
                      
                      <th class="export" colspan="3">Total</th>
                      <th class="export" colspan="2">Rp<?php echo number_format($total_keseluruhan,0,',','.') ?></th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah Transaksi</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    
                                    <label for="id_akun">Nama:</label>
                                    <select id="id_akun" class="custom-select bg-light" name="id_akun" required>
                                        <option selected disabled>Pilih Nama</option>

                                        <?php
                                        $sql = "SELECT * FROM tabel_akun ORDER BY nama_lengkap";
                                        $result = mysqli_query($conn, $sql);
                                        
                                        
                                        foreach ($result as $row) {
                                            
                                        ?>
                                            <option value='<?php echo $row["id"] ?>'><?php echo $row['nama_lengkap']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select> 

                                    <label for="id_mobil">Mobil:</label>
                                    <select id="id_mobil" class="custom-select bg-light" name="id_mobil" required onchange="mobilSelect();">
                                        <option selected disabled>Pilih Mobil</option>

                                        <?php
                                        $sql = "SELECT * FROM tabel_mobil ORDER BY nama";
                                        $result = mysqli_query($conn, $sql);
                                        
                                        
                                        foreach ($result as $row) {

                                          $id_merk = $row['id_merk'];
                                          $merk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_merk WHERE id='$id_merk'"))["nama"];
                                          $mobil = $row['nama'];
                                          $jumlah_mobil = $row['jumlah_mobil'];

                                          $mobil_merk = "$mobil - $merk";
                                        
                                            
                                        ?>
                                            <option value='<?php echo $row["id"] ?>'><?php echo $mobil_merk; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>

                                    <?php
                                    $sql = "SELECT * FROM tabel_mobil ORDER BY nama";
                                    $result = mysqli_query($conn, $sql);
                                    
                                    
                                    foreach ($result as $row) {

                                      $id_merk = $row['id_merk'];
                                      $merk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_merk WHERE id='$id_merk'"))["nama"];
                                      $mobil = $row['nama'];
                                      $jumlah_mobil = $row['jumlah_mobil'];

                                      $mobil_merk = "$mobil - $merk";
                                    
                                        
                                    ?>
                                        <input id="<?php echo $row["id"] ?>-harga" value='<?php echo $row["harga"] ?>' disabled style="display: none !important;"></input>
                                    <?php
                                    }
                                    ?>

                                    <label for="banyak_unit">Banyak Mobil:</label>
                                    <input type="number" name="banyak_unit" id="banyak_unit" class="form-control" placeholder="Masukkan Jumlah" onchange="banyakSelect();" required disabled>

                                    <label for="harga">Harga:</label>
                                    <input type="text" class="form-control form-control-sm"  id="harga" value="" disabled>

                                    <label for="bayar">Pembayaran:</label>
                                    <input type="number" name="bayar" id="bayar" class="form-control" placeholder="Masukkan Pembayaran" required disabled> 

                                   

                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": [{extend: "excel", exportOptions: {columns: ['.export']}}, {extend: "pdf", exportOptions: {columns: ['.export']}}, "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });

  function total() {
   var harga =  parseInt(document.getElementById('harga_barang').value);
   var jumlah_beli =  parseInt(document.getElementById('quantity').value);
   var jumlah_harga = harga * jumlah_beli;
    document.getElementById('subtotal').value = jumlah_harga;
  }


</script>

<script>
  function mobilSelect() {
    document.getElementById("banyak_unit").value = null;
    document.getElementById("harga").value = null;
    document.getElementById("bayar").disabled = true;

    document.getElementById("banyak_unit").disabled = false;
  };

  function banyakSelect() {
    const idMobil = parseInt(document.getElementById("id_mobil").value);
    const banyakMobil = parseInt(document.getElementById("banyak_unit").value);
    const hargaMobil = parseInt(document.getElementById(`${idMobil}-harga`).value);

    const totalHargaMobil = banyakMobil * hargaMobil;

    document.getElementById("harga").value = totalHargaMobil;
    document.getElementById("bayar").disabled = false;
  };

</script>
</body>
</html>

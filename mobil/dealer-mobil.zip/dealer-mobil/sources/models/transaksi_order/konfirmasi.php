<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";



if (isset($_SESSION["id"])) {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        $sql = "SELECT status FROM tabel_pembelian WHERE id='$id'";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $row = mysqli_fetch_assoc($result);

            if ($row["status"] == 0) {
                $sql = "UPDATE tabel_pembelian SET status='1' WHERE id='$id'";
                $result = mysqli_query($conn, $sql);

                if ($result) {
                    echo "<script>alert('Pesanan di terima');</script>";
                    echo "<script>window.location='tabel.php';</script>";
                } else if (!$result) {
                    echo '<script>alert("Pesanan gagal di terima");</script>';
                }
            } 
        }
    }
}

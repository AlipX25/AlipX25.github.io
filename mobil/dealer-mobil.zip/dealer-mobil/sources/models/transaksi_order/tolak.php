<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";



if (isset($_SESSION["id"])) {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $banyak_unit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT banyak_unit FROM tabel_pembelian WHERE id='$id'"))["banyak_unit"];
        $id_mobil = $_GET['id_mobil'];
        $jumlah_mobil_hitung = mysqli_fetch_assoc(mysqli_query($conn, "SELECT jumlah_mobil FROM tabel_mobil WHERE id='$id_mobil'"))["jumlah_mobil"];

        $sql = "SELECT status FROM tabel_pembelian WHERE id='$id'";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $row = mysqli_fetch_assoc($result);


            if ($row["status"] == 0) {
                $sql = "UPDATE tabel_pembelian SET status='3' WHERE id='$id'";
                $result = mysqli_query($conn, $sql);

                if ($result) {

                    $stok_mobil = $jumlah_mobil_hitung + $banyak_unit;

                    $sql = "UPDATE tabel_mobil SET  jumlah_mobil='$stok_mobil' WHERE id='$id_mobil'";
                    $result = mysqli_query($conn, $sql);
                    
                    echo "<script>alert('Pesanan di tolak');</script>";
                    echo "<script>window.location='tabel.php';</script>";
                } else if (!$result) {
                    echo '<script>alert("Pesanan gagal di tolak");</script>';
                }
            } 
        }
    }
}

<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_POST['tambahButton'])){
            $id_merk = $_POST['id_merk'];
            $id_jenis = $_POST['id_jenis'];
            $nama = $_POST['nama'];
            $tahun = $_POST['tahun'];
            $jumlah_mobil = $_POST['jumlah_mobil'];
            $harga = $_POST['harga'];
            $gambar = $_FILES['gambar']['name'];

            $allowed_exttension = array('gif', 'png', 'jpg', 'jpeg');
            $filename = $_FILES['gambar']['name'];
            $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
            if (!in_array($file_extension, $allowed_exttension))
            {
                echo "<script>alert('hanya boleh jpg png jpeg dan gif);</script>";
                echo "<script>window.location='tabel.php';</script>";
            }
            else
            {
                if(file_exists("../gambar_mobil/" . $_FILES['gambar']['name']))
                {
                    $filename = $_FILES['gambar']['name'];
                    echo "<script>alert('gambar sudah ada);</script>";
                    echo "<script>window.location='tabel.php';</script>";
                }
                else 
                {

                    $sql = "INSERT INTO tabel_mobil (id_merk, id_jenis, nama, tahun, jumlah_mobil, harga, gambar) VALUES ('$id_merk', '$id_jenis', '$nama', '$tahun', '$jumlah_mobil', '$harga', '$gambar')";
                    $result = mysqli_query($conn, $sql);

                    if($result)
                    {
                        move_uploaded_file($_FILES["gambar"]["tmp_name"], "../gambar_mobil/".$_FILES["gambar"]["name"]);
                        echo "<script>alert('Data berhasil dimasukkan');</script>";
                        echo "<script>window.location='tabel.php';</script>";
                    }
                    else
                    {
                        echo "<script>alert('Data gagal dimasukkan');</script>";
                        echo "<script>window.location='tabel.php';</script>";
                    }
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data Mobil</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'mobil'; include "$sourcePath/components/sidebar.php";


  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Mobil</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#tambahData" style="margin-bottom: 30px;">Tambah Mobil</button>

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Mobil </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                  <thead>
                  <tr>
                      <th class="export">No</th>
                      <th class="export">Merek</th>
                      <th class="export">Jenis Mobil</th>
                      <th class="export">Nama</th>
                      <th class="export">Tahun</th>
                      <th class="export">Jumlah Mobil</th>
                      <th class="export">Harga</th>
                      <th>Gambar</th>
                      <th class="export">Dibuat</th>
                      <th class="export">Diubah</th>
                      <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $sql = "SELECT * FROM tabel_mobil ORDER BY nama";
                  $result = mysqli_query($conn, $sql);
                  $no = 0;
                  foreach ($result as $row) {
                      $no++;

                      $id_merk = $row['id_merk'];
                      $merk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_merk WHERE id='$id_merk'"))["nama"];
                      $id_jenis = $row['id_jenis'];
                      $jenis = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_jenis WHERE id='$id_jenis'"))["nama"];

                  ?>
                      <tr>
                          <td><?php echo $no; ?></td>
                          <td><?php echo $merk; ?></td>
                          <td><?php echo $jenis; ?></td>
                          <td><?php echo $row['nama']; ?></td>
                          <td><?php echo $row['tahun']; ?></td>
                          <td><?php echo $row['jumlah_mobil']; ?></td>
                          <td>Rp <?php echo number_format($row['harga'],0,',','.'); ?></td>
                          <td><a type="submit" href="<?php echo $sourcePath ?>/models/lihat_gambar/mobil.php?id=<?php echo $row['id'] ?>"><img style="width: 50px;" src="../gambar_mobil/<?php echo $row['gambar'];?>" alt=""></a></td> 
                          <td><?php echo $row['dibuat']; ?></td>
                          <td><?php echo $row['diupdate']; ?></td>
                          <td>
                              <form action="hapus.php" method="POST">
                                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                  <input type="hidden" name="delete_gambar" value="<?php echo $row['gambar']; ?>">
                                  <button type="submit" class="btn btn-danger center-block" name="delete_data">Hapus</button>
                              </form>
                              <a style="margin-left: 0.5rem !important" type=x"submit" class="btn btn-info center-block" href="ubah.php?id=<?php echo $row['id']; ?>&id_merk=<?php echo $row['id_merk']  ?>">Ubah</a>
                          </td>
                      </tr>
                  <?php
                  }
                  ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
  </div>


 
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah Mobil</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    <label for="id_merk">Merek Mobil:</label>
                                    <select  class="form-control" name="id_merk" id="id_merk">
                                      <option  value="" class="ms-auto"></option>
                                    </select>

                                    <label for="id_jenis">Jenis Mobil:</label>
                                    <select  class="form-control" name="id_jenis" id="id_jenis">
                                      <option value=""></option>
                                    </select>      

                                    <label for="nama">Nama:</label>
                                    <input type="text" name="nama" id="nama" class="form-control" placeholder="Masukkan nama" required>

                                    <label for="tahun">Tahun Produksi:</label>
                                    <input type="text" name="tahun" id="tahun" class="form-control" placeholder="Masukkan Tahun" required>

                                    <label for="jumlah_mobil">Jumlah Mobil:</label>
                                    <input type="number" name="jumlah_mobil" id="jumlah_mobil" class="form-control" placeholder="Masukkan Jumlah Mobil" required>

                                    <label for="harga">Harga</label>
                                    <input type="number" name="harga" id="harga" class="form-control" placeholder="Masukkan Harga" required>

                                    <label for="gambar">Gambar:</label>
                                    <input type="file" name="gambar" id="gambar" class="form-control" required>



                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

           
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": [{extend: "excel", exportOptions: {columns: ['.export']}}, {extend: "pdf", exportOptions: {columns: ['.export']}}, "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });

  $(document).ready(function(){
      	$.ajax({
            type: 'POST',
          	url: "<?php echo $sourcePath ?>/public/ajax/merk.php",
          	cache: false, 
          	success: function(msg){
              $("#id_merk").html(msg);
            }
        });
 
      	$("#id_merk").change(function(){
      	var merk = $("#id_merk").val();
          	$.ajax({
          		type: 'POST',
              	url: "<?php echo $sourcePath ?>/public/ajax/jenis.php",
              	data: {merk: merk},
              	cache: false,
              	success: function(msg){
                  $("#id_jenis").html(msg);
                }
            });
        });
     });
</script>
</body>
</html>

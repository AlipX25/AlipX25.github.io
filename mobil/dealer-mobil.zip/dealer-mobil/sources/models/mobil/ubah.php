<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

function cek($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$quer = "SELECT * FROM  tabel_perusahaan";
$res = mysqli_query($conn, $quer);
$data_perusahaan = mysqli_fetch_assoc($res);

if (isset($_SESSION["id"])) {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        $sql = "SELECT * FROM tabel_mobil WHERE id='$id'";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $data = mysqli_fetch_assoc($result);
            $id_merk = $data['id_merk'];
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['update'])) {
            $id = $_GET['id'];

            $id_merk = cek($_POST['id_merk']);
            $id_jenis = cek($_POST['id_jenis']);
            $nama = cek($_POST['nama']);
            $tahun = cek($_POST['tahun']);
            $jumlah_mobil = cek($_POST['jumlah_mobil']);
            $harga = cek($_POST['harga']);

            $new_image = $_FILES['gambar']['name'];
            $old_image = $_POST['gambar_lama'];

            if($new_image != '')
            {
              $update_filename = $_FILES['gambar']['name'];
            }
            else
            {
              $update_filename = $old_image;
            }

            if($_FILES['gambar']['name'] !='')
            {
              if(file_exists("../gambar_mobil/" . $_FILES['gambar']['name']))
              {
                echo "<script>alert('data sudah ada');</script>";
                echo "<script>window.location='ubah.php?id=$id';</script>";
              }
              
              else{
                $sql = "UPDATE tabel_mobil SET id_merk='$id_merk', id_jenis='$id_jenis', nama='$nama', tahun='$tahun', jumlah_mobil='$jumlah_mobil', harga='$harga', gambar='$update_filename' WHERE id='$id'";
                $result = mysqli_query($conn, $sql);

                if($result)
                {
                  if($_FILES['gambar']['name'] !='')
                  {
                    move_uploaded_file($_FILES["gambar"]["tmp_name"], "../gambar_mobil/".$_FILES["gambar"]["name"]);
                    unlink("../gambar_mobil/".$old_image);
                  }

                  echo "<script>alert('Data berhasil diubah');</script>";
                  echo "<script>window.location='ubah.php?id=$id';</script>";
                }
                else
                {
                  echo "<script>alert('Data gagal diubah');</script>";
                  echo "<script>window.location='ubah.php?id=$id';</script>";
                }

              }
            } else if (($_FILES['gambar']['name'] == '')) {
              $sql = "UPDATE tabel_mobil SET id_merk='$id_merk', id_jenis='$id_jenis', nama='$nama', tahun='$tahun', jumlah_mobil='$jumlah_mobil', harga='$harga' WHERE id='$id'";
              $result = mysqli_query($conn, $sql);

              if($result)
              {
                echo "<script>alert('Data berhasil diubah');</script>";
                echo "<script>window.location='ubah.php?id=$id';</script>";
              }
              else
              {
                echo "<script>alert('Data gagal diubah');</script>";
                echo "<script>window.location='ubah.php?id=$id';</script>";
              }
            }
          
        }
    }
            
}            

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewponama" content="width=device-width, initial-scale=1">
  <title>Ubah Mobil</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="icon" href="<?php echo $sourcePath ?>/models/perusahaan/gambar/<?php echo $data_perusahaan['gambar'];   ?>" type="image/icon-type">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $sourcePath ?>/public/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $sourcePath ?>/public/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php include "$sourcePath/components/navbar.php"; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include "$sourcePath/components/sidebar.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ubah Data Mobil</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Masukkan Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form stanama -->
              <form action="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $_GET["id"]; ?>" method="post" enctype="multipart/form-data">
                <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="id_merk">Merek Mobil</label>
                            <select id="id_merk" class="custom-select bg-light" name="id_merk" required>

                                <?php
                                $sql = "SELECT id, nama FROM tabel_merk ORDER BY nama";
                                $result = mysqli_query($conn, $sql);

                                foreach ($result as $row) {
                                  if ($row['id'] == $id_merk) {
                                ?>
                                    <option value='<?php echo $row["id"] ?>' selected><?php echo $row["nama"] ?></option>
                                <?php
                                  } else {
                                ?>
                                    <option value='<?php echo $row["id"] ?>'><?php echo $row["nama"] ?></option>
                                <?php
                                  }
                                }
                                ?>

                              <!-- <option  value=""></option> -->
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="id_jenis">Jenis Mobil</label>
                            <select id="id_jenis" class="custom-select bg-light" name="id_jenis" required>
                                <option disabled >Pilih Jenis</option>
                                <?php 
                                $sql = "SELECT id, id_merk, nama FROM tabel_jenis WHERE id_merk='$id_merk'";
                                $result = mysqli_query($conn, $sql);

                                foreach ($result as $row) {
                                  if ($row['id_merk'] == $id_merk) {
                                ?>
                                    <option value='<?php echo $row["id"] ?>' selected><?php echo $row["nama"] ?></option>
                                <?php
                                  } else {
                                ?>
                                    <option value='<?php echo $row["id"] ?>'><?php echo $row["nama"] ?></option>
                                <?php
                                  }
                                }
                                ?>
                            </select> 
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama Mobil" value="<?php echo $data['nama']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input type="text" class="form-control" id="tahun" name="tahun" placeholder="Masukkan Tahun" value="<?php echo $data['tahun']; ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <div class="form-group">
                            <label for="jumlah_mobil">Jumlah Mobil</label>
                            <input type="text" class="form-control" id="jumlah_mobil" name="jumlah_mobil" placeholder="Masukkan Jumlah Mobil" value="<?php echo $data['jumlah_mobil']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                          <div class="form-group">
                              <label for="harga">Harga</label>
                              <input type="text" class="form-control" id="harga" name="harga" placeholder="Masukkan Harga" value="<?php echo $data['harga']; ?>">
                          </div>
                      </div>
                    
                </div>
                <div class="row">
                  
                    <div class="col-md-6">
                    <label for="gambar">Gambar</label>
                        <div class="input-group">
                            <div class="custom-file">
                                <input type="file" name="gambar" class="custom-file-input" >
                                <input type="hidden" name="gambar_lama" class="form-control bg-light" value="<?php echo $data['gambar']; ?>">
                                <label class="custom-file-label">Pilih file</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="gambar-bg col" style=" margin-top: 30px;">
                            <img style="width: 100px; " src="<?php echo "../gambar_mobil/".$data['gambar'];   ?>" alt="">
                        </div>
                    </div>
                </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" id='update' name='update' class="btn btn-primary">Ubah</button>
                  <a type="button" class="btn btn-danger center-block" href="tabel.php">Kembali</a>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
  <?php include "$sourcePath/components/footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo $sourcePath ?>/public/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
<script type="text/javascript">
	 $(document).ready(function(){
      	// $.ajax({
        //     type: 'POST',
        //   	url: "<?php echo $sourcePath ?>/public/ajax/ubah_merk.php",
        //     data: {
        //           merk: merk
        //         },
        //   	cache: false, 
        //   	success: function(msg){
        //       $("#id_merk").html(msg);
        //     }
        // });
 
      	$("#id_merk").change(function(){
      	var merk = $("#id_merk").val();
          	$.ajax({
          		type: 'POST',
              	url: "<?php echo $sourcePath ?>/public/ajax/ubah_jenis.php",
              	data: {
                  merk: merk
                },
              	cache: false,
              	success: function(msg){
                  $("#id_jenis").html(msg);
                }
            });
        });
     });
</script>
</body>
</html>

<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");



if (isset($_SESSION["id"])) {

    $type = null;
    if (isset($_GET['type'])){
        $type = $_GET['type'];
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['tambahButton'])) {
            $id_akun = $_POST['id_akun'];
            $id_mobil = $_POST['id_mobil'];
            $banyak_unit = $_POST['banyak_unit'];
            $bayar = $_POST['bayar'];
            $status = '1';
            $jumlah_mobil_hitung = mysqli_fetch_assoc(mysqli_query($conn, "SELECT jumlah_mobil FROM tabel_mobil WHERE id='$id_mobil'"))["jumlah_mobil"];
            $harga_mobil_hitung = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga FROM tabel_mobil WHERE id='$id_mobil'"))["harga"];
            
             if($jumlah_mobil_hitung >= $banyak_unit && $harga_mobil_hitung <= $bayar){

            

            $sql = "INSERT INTO tabel_pembelian (id_akun, id_mobil, banyak_unit, bayar, status) VALUES ('$id_akun', '$id_mobil', '$banyak_unit', '$bayar', '$status')";
            $result = mysqli_query($conn, $sql);

            if ($result) {

              // $sql = "SELECT * FROM tabel_pembelian ORDER BY nama_pembeli";
              // $result = mysqli_query($conn, $sql);
              // $data_mobil = mysqli_fetch_assoc($result);
              // $id_mobil = $data_mobil['id_mobil'];

              
              // $jumlah_mobil_dibeli = $data_mobil['banyak_unit'];

              $stok_mobil = $jumlah_mobil_hitung - $banyak_unit;

              $sql = "UPDATE tabel_mobil SET  jumlah_mobil='$stok_mobil' WHERE id='$id_mobil'";
              $result = mysqli_query($conn, $sql);

                echo "<script>alert('Data berhasil dibuat');</script>";
                echo "<script>window.location='tabel.php';</script>";
            } else if (!$result) {
                echo '<script>alert("Data gagal dibuat");</script>';
            }
          }
          else {
            echo '<script>alert("Mobil Habis atau Pembayaran Kurang");</script>';
          }
        }
        
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Data Transaksi</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'rekap_data'; include "$sourcePath/components/sidebar.php";

  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Transaksi</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            


            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Riwayat Transaksi</h3>
                
              </div>
              <!-- /.card-header -->
              
            
              <div class="card-body">

              <div class="row mb-4">
                <div class="col">
                  <form method="post" class="form-inline">
                    <input type="date" name="tgl_mulai" class="form-control">
                    <input type="date" name="tgl_selesai" class="form-control ml-3">
                    <button type="submit" name="filter_tgl" class="btn btn-primary ml-3">Filter</button>
                  </form>
                  
                </div>

                <form method="post" class="form-inline">
                <select style="border-radius: 5px; padding-top: 6.5px; padding-bottom: 6.5px; border: none; background-color: #007BFF; color: #f4f6f9;" name="filter_data" id="filter_data" onchange="window.location=`?type=${document.getElementById('filter_data').value}`">
                <option style="text-align: center;" disabled>Filter Tanggal</option>
                <option name="semua" value="all" style="text-align: center;" selected>Semua</option>
                

                <?php if($type == 'day') { ?>
                    <option name="hari" value="day" style="text-align: center;" selected>Hari ini</option>
                <?php } else { ?>
                   <option name="hari" value="day" style="text-align: center;">Hari ini</option>
                <?php } ?>

                <?php if($type == 'month') { ?>
                    <option name="bulan" value="month" style="text-align: center;" selected>Satu bulan terakhir</option>
                <?php } else { ?>
                   <option name="bulan" value="month" style="text-align: center;">satu bulan terakhir</option>
                <?php } ?>

                <?php if($type == 'year') { ?>
                    <option name="tahun" value="year" style="text-align: center;" selected>Satu tahun terakhir</option>
                <?php } else { ?>
                   <option name="tahun" value="year" style="text-align: center;">Satu tahun terakhir</option>
                <?php } ?>
                
                </select>
                
                </form>

              </div>
              
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                
                  <thead>
                  <tr>
                      <th>No</th>
                      <th>Nama</th>
                      <th>Alamat</th>
                      <th>Nomor HP</th> 
                      <th>Mobil</th> 
                      <th>Banyak Unit</th>
                      <th>Harga</th>
                      <th>Total Bayar</th>
                      <th>Dibuat</th>
                     
                  </tr>
                  </thead>
                  
                  <tbody>
                      <?php
                      $tgl = date("Y-m-d");
                      $bln = date("Y-m-d H:i:s",strtotime("-1 month"));
                      $thn = date("Y-m-d H:i:s",strtotime("-1 year"));
                      
                      if($type == 'day'){
                      
                          $sql = "SELECT * FROM tabel_pembelian WHERE status='1' AND dibuat BETWEEN '$tgl 00:00:00' AND '$tgl 23:59:59' ORDER BY dibuat DESC";
                          $result = mysqli_query($conn, $sql);

                        } else if($type == 'month'){
                          $sql = "SELECT * FROM tabel_pembelian WHERE status='1' AND dibuat BETWEEN '$bln' AND '$tgl 23:59:59' ORDER BY dibuat DESC";
                          $result = mysqli_query($conn, $sql);
                        } else if($type == 'year'){
                            $sql = "SELECT * FROM tabel_pembelian WHERE status='1' AND dibuat BETWEEN '$thn' AND '$tgl 23:59:59' ORDER BY dibuat DESC";
                            $result = mysqli_query($conn, $sql);

                        } else if(isset($_POST['filter_tgl'])){
                            $mulai = $_POST['tgl_mulai'];
                            $selesai = $_POST['tgl_selesai'];
    
                            if($mulai!=null || $selesai!=null){
                              $sql = "SELECT * FROM tabel_pembelian WHERE status='1' AND dibuat BETWEEN '$mulai' AND DATE_ADD('$selesai',INTERVAL 1 DAY) ORDER BY dibuat DESC";
                              $result = mysqli_query($conn, $sql);
                            } else {
                              $sql = "SELECT * FROM tabel_pembelian WHERE status='1'  ORDER BY dibuat DESC";
                              $result = mysqli_query($conn, $sql);
                            }
                           
                          } else {
                            $sql = "SELECT * FROM tabel_pembelian WHERE status='1' ORDER BY dibuat DESC";
                            $result = mysqli_query($conn, $sql);
                          }
                       
                      
                      $no = 0;
                      $total = 0;
                      foreach ($result as $row) {
                          $no++;
                          $id_mobil = $row['id_mobil'];
                          $nama_mobil =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_mobil WHERE id='$id_mobil'"))["nama"];
                          $harga = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga FROM tabel_mobil WHERE id='$id_mobil'"))["harga"];
                          $bayar = $row['bayar'];

                          $jumlah_mobil_dibeli = $row['banyak_unit'];
                          $hasil= $bayar - $jumlah_mobil_dibeli * $harga;
                          $total_transaksi = $bayar - $hasil;

                          $id_akun = $row['id_akun'];
                          $nama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama_lengkap FROM tabel_akun WHERE id='$id_akun'"))["nama_lengkap"];
                          $alamat_pembeli = mysqli_fetch_assoc(mysqli_query($conn, "SELECT alamat FROM tabel_akun WHERE id='$id_akun'"))["alamat"];
                          $no_hp = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nomor_hp FROM tabel_akun WHERE id='$id_akun'"))["nomor_hp"];

                          if ($bayar >= 1){
                            $total += $harga * $row['banyak_unit'];
                          }
                          

                      ?>
                          <tr>
                              <td><?php echo $no; ?></td>
                              <td><?php echo $nama; ?></td>
                              <td><?php echo $alamat_pembeli; ?></td>
                              <td><?php echo $no_hp; ?></td>
                              <td><?php echo $nama_mobil; ?></td>
                              <td><?php echo $row['banyak_unit']; ?></td>
                              <td>Rp<?php echo number_format($total_transaksi,0,',','.'); ?></td>
                              <?php
                              if($row['bayar'] == 0) 
                              {?>
                     
                              <td><a style="margin-bottom: 5px;margin-left: 0.5rem !important;" type="submit" class="btn btn-success center-block" href="ubah.php?id=<?php echo $row['id']; ?>"><i class="fas fa-pencil-alt"></i></a></td>
                              <?php 
                              } else{?>
                              <td>Rp<?php echo number_format($row['bayar'],0,',','.'); ?></td>
                              <?php 
                              } ?>
                              <td><?php echo $row['dibuat']; ?></td>
                              
                          </tr>
                      <?php
                      }
                      ?>
                  </tbody>

                  <tfoot>
                  <tr>
                     
                      <th colspan="6">Total</th>
                      <th colspan="3">Rp<?php echo number_format($total,0,',','.') ?></th>
                      
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah Transaksi</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    
                                    <label for="id_akun">Nama:</label>
                                    <select id="id_akun" class="custom-select bg-light" name="id_akun" required>
                                        <option selected disabled>Pilih Nama</option>

                                        <?php
                                        $sql = "SELECT * FROM tabel_akun ORDER BY nama_lengkap";
                                        $result = mysqli_query($conn, $sql);
                                        
                                        
                                        foreach ($result as $row) {
                                            
                                        ?>
                                            <option value='<?php echo $row["id"] ?>'><?php echo $row['nama_lengkap']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select> 

                                    <label for="id_mobil">Mobil:</label>
                                    <select id="id_mobil" class="custom-select bg-light" name="id_mobil" required onchange="mobilSelect();">
                                        <option selected disabled>Pilih Mobil</option>

                                        <?php
                                        $sql = "SELECT * FROM tabel_mobil ORDER BY nama";
                                        $result = mysqli_query($conn, $sql);
                                        
                                        
                                        foreach ($result as $row) {

                                          $id_merk = $row['id_merk'];
                                          $merk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_merk WHERE id='$id_merk'"))["nama"];
                                          $mobil = $row['nama'];
                                          $jumlah_mobil = $row['jumlah_mobil'];

                                          $mobil_merk = "$mobil - $merk";
                                        
                                            
                                        ?>
                                            <option value='<?php echo $row["id"] ?>'><?php echo $mobil_merk; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>

                                    <?php
                                    $sql = "SELECT * FROM tabel_mobil ORDER BY nama";
                                    $result = mysqli_query($conn, $sql);
                                    
                                    
                                    foreach ($result as $row) {

                                      $id_merk = $row['id_merk'];
                                      $merk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_merk WHERE id='$id_merk'"))["nama"];
                                      $mobil = $row['nama'];
                                      $jumlah_mobil = $row['jumlah_mobil'];

                                      $mobil_merk = "$mobil - $merk";
                                    
                                        
                                    ?>
                                        <input id="<?php echo $row["id"] ?>-harga" value='<?php echo $row["harga"] ?>' disabled style="display: none !important;"></input>
                                    <?php
                                    }
                                    ?>

                                    <label for="banyak_unit">Banyak Mobil:</label>
                                    <input type="number" name="banyak_unit" id="banyak_unit" class="form-control" placeholder="Masukkan Jumlah" onchange="banyakSelect();" required disabled>

                                    <label for="harga">Harga:</label>
                                    <input type="text" class="form-control form-control-sm"  id="harga" value="" disabled>

                                    <label for="bayar">Pembayaran:</label>
                                    <input type="number" name="bayar" id="bayar" class="form-control" placeholder="Masukkan Pembayaran" required disabled> 

                                   

                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["excel", "pdf", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });

  function total() {
   var harga =  parseInt(document.getElementById('harga_barang').value);
   var jumlah_beli =  parseInt(document.getElementById('quantity').value);
   var jumlah_harga = harga * jumlah_beli;
    document.getElementById('subtotal').value = jumlah_harga;
  }


</script>

<script>
  function mobilSelect() {
    document.getElementById("banyak_unit").value = null;
    document.getElementById("harga").value = null;
    document.getElementById("bayar").disabled = true;

    document.getElementById("banyak_unit").disabled = false;
  };

  function banyakSelect() {
    const idMobil = parseInt(document.getElementById("id_mobil").value);
    const banyakMobil = parseInt(document.getElementById("banyak_unit").value);
    const hargaMobil = parseInt(document.getElementById(`${idMobil}-harga`).value);

    let totalHargaMobil = banyakMobil * hargaMobil;
    let formattedTotalHargaMobil = Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR'
    }).format(totalHargaMobil);

    document.getElementById("harga").value = formattedTotalHargaMobil;
    document.getElementById("bayar").disabled = false;
  };

</script>
</body>
</html>

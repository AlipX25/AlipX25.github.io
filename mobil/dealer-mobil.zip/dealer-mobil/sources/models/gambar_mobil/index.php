<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/redirectIndex.php";

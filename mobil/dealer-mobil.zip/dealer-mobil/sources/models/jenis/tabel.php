<?php
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 2, "$sourcePath/../");

if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['tambahButton'])) {
            $id_merk = $_POST['id_merk'];
            $nama = $_POST['nama'];

            $sql = "INSERT INTO tabel_jenis (id_merk, nama) VALUES ('$id_merk', '$nama')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                echo "<script>alert('Data berhasil dibuat');</script>";
                echo "<script>window.location='tabel.php';</script>";
            } else if (!$result) {
                echo '<script>alert("Data gagal dibuat");</script>';
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Jenis Mobil</title>
  <?php

  include "$sourcePath/components/header-tabel.php";

  ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php

    include "$sourcePath/components/navbar.php"

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <?php

$currentPageActive = 'jenis'; include "$sourcePath/components/sidebar.php";


  ?>   

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Jenis</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->
            <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#tambahData" style="margin-bottom: 30px;">Tambah Jenis</button>


            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Jenis Mobil </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped" style="text-align: center;">
                  <thead>
                  <tr>
                      <th class="export">No</th>
                      <th class="export">Jenis</th>
                      <th class="export">Dibuat</th>
                      <th class="export">Diubah</th>
                      <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                      <?php
                      $sql = "SELECT * FROM tabel_jenis ORDER BY nama";
                      $result = mysqli_query($conn, $sql);
                      $no = 0;
                      foreach ($result as $row) {
                          $no++;
                          $id_merk = $row['id_merk'];
                          $merk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM tabel_merk WHERE id='$id_merk'"))["nama"];
                          $jenis = $row['nama'];
                          $merk_jenis = "$jenis - $merk";

                      ?>
                          <tr>
                              <td><?php echo $no; ?></td>
                              <td><?php echo $merk_jenis; ?></td>
                              <td><?php echo $row['dibuat']; ?></td>
                              <td><?php echo $row['diupdate']; ?></td>
                              <td style="display: flex; flex-direction: row; justify-content: center;">
                                  <a type="submit" class="btn btn-danger center-block" href="hapus.php?id=<?php echo $row['id']; ?>">Hapus</a>
                                  <a style="margin-left: 0.5rem !important" type="submit" class="btn btn-info center-block" href="ubah.php?id=<?php echo $row['id']; ?>">Ubah</a>
                              </td>
                          </tr>
                      <?php
                      }
                      ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php

    include "$sourcePath/components/footer.php";

  ?>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Tambah Jenis</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="tambahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    <label for="id_merk">Merek:</label>
                                    <select id="id_merk" class="custom-select bg-light" name="id_merk" required>
                                        <option selected disabled>Pilih Merek</option>

                                        <?php
                                        $sql = "SELECT * FROM tabel_merk ORDER BY nama";
                                        $result = mysqli_query($conn, $sql);
                                        
                                        
                                        foreach ($result as $row) {
                                            
                                        ?>
                                            <option value='<?php echo $row["id"] ?>'><?php echo $row['nama']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select> 
                                      

                                    <label for="nama">Nama:</label>
                                    <input type="text" name="nama" id="nama" class="form-control" placeholder="Masukkan nama" required> 

                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="tambahButton" id="tambahButton" form="tambahDataForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo $sourcePath ?>/public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": [{extend: "excel", exportOptions: {columns: ['.export']}}, {extend: "pdf", exportOptions: {columns: ['.export']}}, "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>

<?php
	$sourcePath = "./../..";
    include "$sourcePath/utilities/koneksi.php";
    include "$sourcePath/utilities/session.php";
    include "$sourcePath/utilities/sessionData.php";
    include "$sourcePath/utilities/isNotActive.php";
    include "$sourcePath/utilities/isNotAuthenticated.php";
    include "$sourcePath/utilities/role.php";
    
	$merk = $_POST['merk'];

	echo "<option value=''>Pilih Jenis</option>";

	$query = "SELECT * FROM tabel_jenis WHERE id_merk=? ORDER BY nama ASC";
	$hasil = $conn->prepare($query);
	$hasil->bind_param("i", $merk);
	$hasil->execute();
	$res1 = $hasil->get_result();
	while ($row = $res1->fetch_assoc()) {
		echo "<option value='" . $row['id'] . "'>" . $row['nama'] . "</option>";
	}
?>
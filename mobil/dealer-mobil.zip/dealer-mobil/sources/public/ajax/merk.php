<?php 
$sourcePath = "./../..";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";


 echo "<option value=''>Pilih Merk</option>";

 $query = "SELECT * FROM tabel_merk ORDER BY nama ASC";
 $hasil = $conn->prepare($query);
 $hasil->execute();
 $res1 = $hasil->get_result();
 while ($row = $res1->fetch_assoc()) {
    echo "<option value='" . $row['id'] . "'>" . $row['nama'] . "</option>";
 }

  

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $sourcePath; ?>/public/plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $sourcePath; ?>/public/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo $sourcePath; ?>/public/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo $sourcePath; ?>/public/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $sourcePath; ?>/public/dist/css/adminlte.min.css">
<!-- image -->
<?php

$quer = "SELECT * FROM  tabel_perusahaan";
$res = mysqli_query($conn, $quer);
$data_perusahaan = mysqli_fetch_assoc($res);

?>
<link rel="icon" href="<?php echo $sourcePath; ?>/models/perusahaan/<?php echo "gambar/".$data_perusahaan['gambar'];   ?>" type="image/icon-type">
<!-- Main Sidebarainer -->

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo $sourcePath; ?>/../index.php" class="brand-link">
      <img src="<?php echo $sourcePath; ?>/models/perusahaan/<?php echo "gambar/".$data_perusahaan['gambar'];   ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light"><?php echo $data_perusahaan['nama']; ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo $sourcePath; ?>/models/user/<?php echo "gambar/".$sessionGambar;   ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class=""><?php echo $sessionNamaLengkap ?>
            <a href="<?php echo $sourcePath; ?>/logout.php">
              <i style="margin-left: 40px;" class="fa fa-sign-out-alt right"></i>
            </a>
          </a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item">
                    <a href="<?php echo $sourcePath; ?>/../index.php" class="nav-link <?php echo ($currentPageActive == "dashboard" ? "active" : "")?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Dashboard
                    </p>
                    </a>
                </li>
 
        <?php if ($sessionType == "user") { ?>  
          <li class="nav-header">Data Mobil</li>
          
          <li class="nav-item men u-open menu-is-opening menu-open">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-car"></i>
              <p>
                Mobil
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a id="merk-mobil" href="<?php echo $sourcePath; ?>/models/merk/tabel.php" class="nav-link <?php echo ($currentPageActive == "merk" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Merk Mobil </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/jenis/tabel.php" class="nav-link <?php echo ($currentPageActive == "jenis" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Jenis Mobil</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/mobil/tabel.php" class="nav-link <?php echo ($currentPageActive == "mobil" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Mobil</p>
                </a>
              </li>
            </ul>

          <li class="nav-header">Data Transaksi</li>
          
          <li class="nav-item men u-open menu-is-opening menu-open">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-money-check"></i>
              <p>
                Transaksi
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/transaksi/tabel.php" class="nav-link <?php echo ($currentPageActive == "transaksi" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data transaksi</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/transaksi_order/tabel.php" class="nav-link <?php echo ($currentPageActive == "transaksi_order" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Order</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/transaksi_tolak/tabel.php" class="nav-link <?php echo ($currentPageActive == "transaksi_tolak" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Di Tolak</p>
                </a>
              </li>
              
            </ul>

          <li class="nav-header">Rekap Data</li>
          
          <li class="nav-item men u-open menu-is-opening menu-open">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-money-check"></i>
              <p>
                Rekap Data
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/rekap_merk/tabel.php" class="nav-link <?php echo ($currentPageActive == "rekap_merk" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Rekap Merk</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo $sourcePath; ?>/models/rekap_data/tabel.php" class="nav-link <?php echo ($currentPageActive == "rekap_data" ? "active" : "")?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Rekap Semua</p>
                </a>
              </li>
              
            </ul>
            
            <li class="nav-header">Data User</li>
            <?php if (checkRole($sessionRole, 3)) { ?>
                <li class="nav-item">
                    <a href="<?php echo $sourcePath; ?>/models/user/tabel.php" class="nav-link <?php echo ($currentPageActive == "user" ? "active" : "")?>">
                    <i class="nav-icon far fa-user"></i>
                    <p>
                        Akun User
                    </p>
                    </a>
                </li>
                <?php } ?>
                <li class="nav-item">
                    <a href="<?php echo $sourcePath; ?>/models/user_pengguna/tabel.php" class="nav-link <?php echo ($currentPageActive == "user_pengguna" ? "active" : "")?>">
                    <i class="nav-icon far fa-user"></i>
                    <p>
                        Akun Pembeli
                    </p>
                    </a>
                </li>
            
            <li class="nav-header">Data Perusahaan</li>
                <li class="nav-item">
                    <a href="<?php echo $sourcePath; ?>/models/perusahaan/tabel.php" class="nav-link <?php echo ($currentPageActive == "perusahaan" ? "active" : "")?>">
                    <i class="nav-icon far fa-address-book"></i>
                    <p>
                        Perusahaan
                    </p>
                    </a>
                </li>
          </li>
        <?php } ?>  
         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
 
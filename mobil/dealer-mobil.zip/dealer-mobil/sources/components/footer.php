<footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="https://adminlte.io">Alief Mastari</a>.</strong>
  
    
  </footer>
<?php
$sourcePath = "./sources";
include "$sourcePath/utilities/koneksi.php";
include "$sourcePath/utilities/session.php";
include "$sourcePath/utilities/sessionData.php";
include "$sourcePath/utilities/isNotActive.php";
include "$sourcePath/utilities/isNotAuthenticated.php";
include "$sourcePath/utilities/role.php";

guardRole($sessionRole, 1, "$sourcePath/../");

if (isset($_SESSION["id"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['UbahDataDiri'])) {
            if ($sessionType == "user") {
                $username = $_POST['username'];
                $nama_lengkap = $_POST['nama_lengkap'];
                $nomor_hp = $_POST['nomor_hp'];
                $email = $_POST['email'];

                if (is_numeric($nomor_hp)) {
                    $sql = "SELECT * FROM tabel_user WHERE username='$username'";
                    $result = mysqli_query($conn, $sql);

                    $numberIncrease = 0;
                    if ($username == $sessionUsername) {
                        $numberIncrease = 1;
                    };

                    if ($result->num_rows <= 0 + $numberIncrease) {
                        $sql = "UPDATE tabel_user SET username='$username', nama_lengkap='$nama_lengkap', nomor_hp='$nomor_hp', email='$email' WHERE id='$sessionId'";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            echo "<script>alert('Data berhasil diupdate');</script>";
                            echo "<script>window.location='index.php';</script>";
                        } else if (!$result) {
                            echo '<script>alert("Data gagal diupdate");</script>';
                        }
                    } else if ($result->num_rows > 0 + $numberIncrease) {
                        echo "<script>alert('Woops! Username sudah terdaftar')</script>";
                    }
                } else if (!is_numeric($nomor_hp)) {
                    echo '<script>alert("Pastikan nomor HP hanya menggunakan angka");</script>';
                }
            } else if ($sessionType == "siswa") {
                $nama_lengkap = $_POST['nama_lengkap'];
                $tempat_lahir = $_POST['tempat_lahir'];
                $tanggal_lahir = $_POST['tanggal_lahir'];
                $jenis_kelamin = $_POST['jenis_kelamin'];
                $id_tahun_masuk = $_POST['id_tahun_masuk'];
                $id_tingkat = $_POST['id_tingkat'];
                $id_jurusan = $_POST['id_jurusan'];
                $id_rombel = $_POST['id_rombel'];

                $sql = "UPDATE tabel_siswa SET nama_lengkap='$nama_lengkap', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir', jenis_kelamin='$jenis_kelamin', id_tahun_masuk='$id_tahun_masuk', id_tingkat='$id_tingkat', id_jurusan='$id_jurusan', id_rombel='$id_rombel' WHERE id='$sessionId'";
                $result = mysqli_query($conn, $sql);

                if ($result) {
                    echo "<script>alert('Data berhasil diupdate');</script>";
                    echo "<script>window.location='index.php';</script>";
                } else if (!$result) {
                    echo '<script>alert("Data gagal diupdate");</script>';
                }
            }
        } else if (isset($_POST["ubahPasswordBaru"])) {
            $password = md5($_POST['password']);
            $cpassword = md5($_POST['cpassword']);

            if ($password == $cpassword) {
                $sql = "UPDATE tabel_user SET password='$password', WHERE id='$sessionId'";
                $result = mysqli_query($conn, $sql);

                if ($result) {
                    echo "<script>alert('Password berhasil diupdate');</script>";
                    echo "<script>window.location='index.php';</script>";
                } else if (!$result) {
                    echo '<script>alert("Password gagal diupdate");</script>';
                }
            } else if ($password != $cpassword) {
                echo "<script>alert('Konfirmasi password salah');</script>";
            }
        }
    }
  }

function getData(String $data)
{
    global $conn;

    switch ($data) {
        case 'merek':
            $query = mysqli_query($conn, "SELECT * FROM tabel_merk");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'jenis':
            $query = mysqli_query($conn, "SELECT * FROM tabel_jenis");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'mobil':
            $query = mysqli_query($conn, "SELECT * FROM tabel_mobil");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'operator':
            $query = mysqli_query($conn, "SELECT * FROM tabel_user WHERE role='operator'");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'admin':
            $query = mysqli_query($conn, "SELECT * FROM tabel_user WHERE role='admin'");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'diterima':
            $query = mysqli_query($conn, "SELECT * FROM tabel_pembelian WHERE status='1'");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'ditolak':
            $query = mysqli_query($conn, "SELECT * FROM tabel_pembelian WHERE status='3'");
            $jumlah = mysqli_num_rows($query);
            break;
        case 'belum':
            $query = mysqli_query($conn, "SELECT * FROM tabel_pembelian WHERE status='0'");
            $jumlah = mysqli_num_rows($query);
            break;
    }
    return $jumlah;
};



?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>
  
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Merek',   <?php echo number_format((float) getData("merek")); ?>],
          ['Jenis',    <?php echo number_format((float) getData("jenis")); ?>],
          ['Mobil', <?php echo number_format((float) getData("mobil")); ?>]
        ]);

        var options = {
          title: 'Data Mobil'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Di terima',   <?php echo number_format((float) getData("diterima")); ?>],
          ['Di tolak',    <?php echo number_format((float) getData("ditolak")); ?>],
          ['Belum di konfirmasi', <?php echo number_format((float) getData("belum")); ?>]
        ]);

        var options = {
          title: 'Data Transaksi'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart2'));

        chart.draw(data, options);
      }
    </script>

  

  <?php

  include "$sourcePath/components/header.php";

  ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="sources/public/dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
    <?php 
    
    include "$sourcePath/components/navbar.php";
    
    ?>
  <!-- /.navbar -->

  
  <?php if ($sessionType == "user") { ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- sidebar nya -->
  <?php

$currentPageActive = 'dashboard';  include "$sourcePath/components/sidebar.php";


  ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo number_format((float) getData("merek")); ?></h3>

                <p>Merek</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <?php if (checkRole($sessionRole, 3)) { ?>
              <a href="<?php echo $sourcePath ?>/models/merk/tabel.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              <?php } ?>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo number_format((float) getData("mobil")); ?></h3>

                <p>Mobil</p>
              </div>
              <div class="icon">
                <i class="ion ion-model-s"></i>
              </div>
              <?php if (checkRole($sessionRole, 3)) { ?>
              <a href="<?php echo $sourcePath ?>/models/mobil/tabel.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              <?php } ?>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo number_format((float) getData("operator")); ?></h3>

                <p>Operator</p>
              </div>
              <div class="icon">
                <i class="ion ion-person"></i>
              </div>
              <?php if (checkRole($sessionRole, 3)) { ?>
              <a href="<?php echo $sourcePath ?>/models/user/tabel.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              <?php } ?>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo number_format((float) getData("admin")); ?></h3>

                <p>Admin</p>
              </div>
              <div class="icon">
                <i class="ion ion-person"></i>
              </div>
              <?php if (checkRole($sessionRole, 3)) { ?>
              <a href="<?php echo $sourcePath ?>/models/user/tabel.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              <?php } ?>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">

        <section class="col-lg-6 connectedSortable" style="margin-bottom: 30px;">

          <div id="piechart"></div>
            

      

            
            <!-- /.card -->
          </section>
          <section class="col-lg-6 connectedSortable">

         
            

          <div id="piechart2"></div>
      

            
            <!-- /.card -->
          </section>

          <!-- Left col -->
          <sectxion class="col-lg-12 connectedSortable">
            <!-- Custom tabs (Charts with tabs)-->
            
            <section class="content">
              <div class="container-fluid">
                <div class="row">
                  <!-- left column -->
                  <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                      <div class="card-header">
                        <h3 class="card-title">Profil Anda</h3>
                      </div>
                      <!-- /.card-header -->
                      <!-- form stanama -->
                      <form action="<?php echo $_SERVER["PHP_SELF"]; ?>?id=<?php echo $_GET["id"]; ?>" method="post" enctype="multipart/form-data">
                        <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username" value="<?php echo $sessionUsername; ?>" readonly>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama_lengkap">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Masukkan Nama Lengkap" value="<?php echo $sessionNamaLengkap; ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nomor_hp">Nomor HP</label>
                                    <input type="number" class="form-control" id="nomor_hp" name="nomor_hp" placeholder="Masukkan Nomor HP" value="<?php echo $sessionNomorHP; ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tahun">Email</label>
                                    <input type="text" class="form-control" id="tahun" name="tahun" placeholder="Masukkan Tahun" value="<?php echo $sessionEmail; ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jumlah_mobil">Role</label>
                                    <input type="text" class="form-control" id="jumlah_mobil" name="jumlah_mobil" placeholder="Masukkan Jumlah Mobil" value="<?php echo ucfirst($sessionRole); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                  <div class="form-group">
                                      <label for="harga">Status</label>
                                      <input type="text" class="form-control" id="harga" name="harga" placeholder="Masukkan Harga" value="<?php echo $sessionAktif == 1 ? 'Aktif' : 'Tidak Aktif'; ?>" readonly>
                                  </div>
                              </div>
                            
                        </div>
                        
                        <!-- /.card-body -->

                        <div class="card-footer">
                          <button type="button"  class="btn btn-primary" data-toggle="modal" data-target="#ubahData">Ubah</button>
                          <a type="button" class="btn btn-danger center-block" href="index.php">Kembali</a>
                          
                        </div>
                      </form>
                    </div>
                    <!-- /.card -->
                    </div>
                </div>
                <!-- /.row -->
              </div><!-- /.container-fluid -->
              
            </section>
            <!-- TO DO List -->
            
          </sectxion>
          <!-- /.Left col -->
          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          
          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <?php } ?>
  <!-- /.content-wrapper -->
   <?php

    include "sources/components/footer.php";

    ?>

              <!-- ubah profil -->

              <div class="modal fade" id="ubahData" tabindex="-1" role="dialog" aria-labelledby="UbahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="UbahDataLabel">Ubah Data</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="ubahDataForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">

                                    <label for="username">Username:</label>
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Masukkan username" value="<?php echo $sessionUsername ?>">

                                    <label for="nama_lengkap">Nama Lengkap:</label>
                                    <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" placeholder="Masukkan Nama Lengkap" value="<?php echo $sessionNamaLengkap ?>">

                                    <label for="nomor_hp">Nomor HP:</label>
                                    <input type="number" name="nomor_hp" id="nomor_hp" class="form-control" placeholder="Masukkan Nomor HP" value="<?php echo $sessionNomorHP ?>">

                                    <label for="email">Email:</label>
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Masukkan Email" value="<?php echo $sessionEmail ?>">


                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="UbahDataDiri" id="UbahDataDiri" form="ubahDataForm" class="btn btn-primary">Ubah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ubah password -->

            <div class="modal fade" id="ubahPassword" tabindex="-1" role="dialog" aria-labelledby="UbahPasswordLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataLabel">Ubah Password</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <form id="ubahPassForm" action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">


                                    <label for="password">Password:</label>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password" required>

                                    <label for="cpassword">Konfirmasi Password:</label>
                                    <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="Konfirmasi Password" required>


                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                                <button type="submit" name="ubahPasswordBaru" id="ubahPasswordBaru" form="ubahPassForm" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="sources/public/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="sources/public/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo $sourcePath ?>/public/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo $sourcePath ?>/public/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?php echo $sourcePath ?>/public/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo $sourcePath ?>/public/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo $sourcePath ?>/public/plugins/moment/moment.min.js"></script>
<script src="<?php echo $sourcePath ?>/public/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo $sourcePath ?>/public/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo $sourcePath ?>/public/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo $sourcePath ?>/public/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $sourcePath ?>/public/dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $sourcePath ?>/public/dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo $sourcePath ?>/public/dist/js/pages/dashboard.js"></script>
</body>
</html>

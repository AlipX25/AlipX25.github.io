<?php
$host = "localhost";
$user = "root";
$password = "admin123";
$db = "db_dealer_mobil";


$conn = mysqli_connect($host, $user, $password, $db)
// if($kon) {
//     die("Database tidak ditemukan" mysqli_connect_error())
// }

?>